.. _web:

Web
===

Example
-------

.. literalinclude:: ../examples/web.py


