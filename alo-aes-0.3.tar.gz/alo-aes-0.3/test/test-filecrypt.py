#! /usr/bin/env python

import sys
import getopt
import os
import binascii

import aes
import sha

def usage(utyp, *msg):
    sys.stderr.write('Usage: %s\n' % os.path.split(sys.argv[0])[1])
    if msg:
        sys.stderr.write('Error: %s\n' % `msg`)
    sys.exit(1)

class Global:
    def __init__(gp):
        gp.key = None
        gp.blen2 = 13
        gp.encrypt = 1
        return
    def doit(gp,args):
        fin = sys.stdin
        fout = sys.stdout

        bkey = sha.new(gp.key).digest()[:16]

        o = aes.Keysetup(bkey)
        b0 = '\x00' * 16
        iv = b0

        if gp.encrypt:
            cfun = o.cbcencrypt
        else:
            cfun = o.cbcdecrypt

        blen = 1 << gp.blen2

        d2 = ''
        ok = 1
        while ok:
            if d2:
                d = fin.read(blen-len(d2))
                if not d:
                    ok = 0
                d = d2 + d
            else:
                d = fin.read(blen)
                if not d:
                    ok = 0
            n1,n2 = divmod(len(d),16)
            if n2:
                d2 = d[n1*16:]
                d = d[:n1*16]
            if d:
                iv2,d = cfun(iv,d)
                fout.write(d)
                iv = iv2
        n2 = len(d2)
        if n2:
            x2 = o.encrypt(iv)
            a = []
            for i in xrange(n2):
                a.append(chr(ord(d2[i])^ord(x2[i])))
            fout.write(''.join(a))
        return

def main(argv):
    gp = Global()
    try:
        opts, args = getopt.getopt(sys.argv[1:],
                                   'hedk:b:',
                                   ['help',
                                    'key='
                                    'blen=',
                                    ])
    except getopt.error, msg:
        usage(1, msg)

    for opt, arg in opts:
        if opt in ('-h', '--help'):
            usage(0)
        elif opt in ('-k', '--key'):
            gp.key = arg
        elif opt in ('-e','--encrypt'):
            gp.encrypt = 1
        elif opt in ('-d','--decrypt'):
            gp.encrypt = 0
        elif opt in ('-b','--blen'):
            gp.blen2 = int(arg)

    gp.doit(args)
        
if __name__ == '__main__':
    main(sys.argv)
