#! /usr/bin/python2.5

assert 0, 'see ../syncless/greenstackless.py instead'
