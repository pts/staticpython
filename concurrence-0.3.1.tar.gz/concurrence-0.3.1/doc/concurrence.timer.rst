:mod:`concurrence.timer` -- A timer module
==================================================

.. module:: concurrence.timer
   :platform: Unix
   :synopsis: A task based Timeout timer
.. moduleauthor:: Henk Punt <henk@hyves.nl>
 
.. autoclass:: Timeout
   :members:
   
   
   
