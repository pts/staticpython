#include <Python.h>

/*
  Copyright 2004 Antti Louko <alo@iki.fi>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License, version 2, or
  any later version.  See file COPYING.

 */

#include <stdio.h>

#include "rijndael-alg-fst.h"

#define DEBUG 0

#if DEBUG
static int	debug = 2;
#define D(x) (debug>5 ? (void)(x) : (void)0)
#define Dn(l,x) (debug>(l) ? (void)(x) : (void)0)
#else
#define D(x) ((void)0)
#define Dn(l,x) ((void)0)
#endif

typedef struct {
  PyObject_HEAD
  u32		rke[60];
  u32		rkd[60];
  int		keyBits;
  int		nr;
} _Aes;

static void
_Aes_dealloc(_Aes* self)
{
  memset(self->rke,0,sizeof(self->rke));
  memset(self->rkd,0,sizeof(self->rkd));
  self->keyBits = 0;
  Dn(1,fprintf(stderr,"_Aes_dealloc %p\n",self));
  self->ob_type->tp_free((PyObject*)self);
}

static PyObject *
_Aes_new(PyTypeObject *type, PyObject *args, PyObject *kwds)
{
  _Aes *self;

  self = (_Aes *)type->tp_alloc(type, 0);
  if (self == NULL)
    goto err;
  memset(self->rke,0,sizeof(self->rke));
  memset(self->rkd,0,sizeof(self->rkd));
  self->keyBits = 0;
  Dn(1,fprintf(stderr,"_Aes_new %p\n",self));
  return (PyObject *)self;
 err:
  Py_XDECREF(self);
  return NULL;
}

static int
_Aes_init(_Aes *self, PyObject *args, PyObject *kwds)
{
  const char	*keystring;
  int	size;
  int keybits;

  if (!PyArg_ParseTuple(args, "s#", &keystring, &size))
    goto err;
  
  if (size == 16)
    keybits = 128;
  else if (size == 24)
    keybits = 192;
  else if (size == 32)
    keybits = 256;
  else {
    PyErr_SetString(PyExc_ValueError, "invalid keysize");
    goto err;
  }
  
  self->keyBits = keybits;
  self->nr = rijndaelKeySetupEnc(self->rke,keystring,self->keyBits);
  self->nr = rijndaelKeySetupDec(self->rkd,keystring,self->keyBits);
  return 0;
 err:
  return -1;
}

PyDoc_STRVAR(_aes_encrypt_doc,
	     "encrypt(self,data)\n\
\n\
AES encryption");

static PyObject *
_aes_encrypt(PyObject *self, PyObject *args)
{
  const u8	*data;
  int	size;
  _Aes *ctx = (_Aes*)self;
  PyObject *rv = 0;
  PyObject *r = 0;

  if (!PyArg_ParseTuple(args, "s#", &data, &size))
    return NULL;

  if ((size % 16) != 0) {
    PyErr_SetString(PyExc_ValueError, "invalid datasize");
    goto err;
  }

  rv = PyString_FromStringAndSize(0, size);
  if (!rv)
    goto err;

  {
    int	nbytes = size;
    u8	*out = 0;
    int	p;

    out = ((PyStringObject*)rv)->ob_sval;

    for(nbytes = size, p = 0; nbytes > 0; nbytes -= 16, p += 16) {
      rijndaelEncrypt(ctx->rke, ctx->nr, data+p, out+p);
    }
  }
  r = rv;
  rv = 0;
 err:
  Py_XDECREF(rv);
  return r;
}

PyDoc_STRVAR(_aes_decrypt_doc,
	     "decrypt(self,data)\n\
\n\
AES decryption");

static PyObject *
_aes_decrypt(PyObject *self, PyObject *args)
{
  const char	*data;
  int	size;
  _Aes *ctx = (_Aes*)self;
  PyObject *rv = 0;
  PyObject *r = 0;
  u8	out[16];

  if (!PyArg_ParseTuple(args, "s#", &data, &size))
    return NULL;

  if ((size % 16) != 0) {
    PyErr_SetString(PyExc_ValueError, "invalid datasize");
    goto err;
  }

  rv = PyString_FromStringAndSize(0, size);
  if (!rv)
    goto err;

  {
    int	nbytes = size;
    u8	*out = 0;
    int	p;

    out = ((PyStringObject*)rv)->ob_sval;

    for(nbytes = size, p = 0; nbytes > 0; nbytes -= 16, p += 16) {
      rijndaelDecrypt(ctx->rkd, ctx->nr, data+p, out+p);
    }
  }
  r = rv;
  rv = 0;
 err:
  Py_XDECREF(rv);
  return r;
}


PyDoc_STRVAR(_aes_cbcencrypt_doc,
	     "cbcencrypt(ctx,iv,data)\n\
\n\
AES CBC encryption");

static PyObject *
_aes_cbcencrypt(PyObject *self, PyObject *args)
{
  const char	*data;
  int	size;
  const char	*ivdata;
  int	ivsize;
  _Aes *ctx = (_Aes*)self;
  PyObject *rv = 0;
  PyObject *rv2 = 0;
  PyObject *r = 0;

  if (!PyArg_ParseTuple(args, "s#s#", &ivdata, &ivsize, &data, &size))
    return NULL;

  if (ivsize != 16) {
    PyErr_SetString(PyExc_ValueError, "invalid ivsize");
    return NULL;
  }

  if ((size % 16) != 0) {
    PyErr_SetString(PyExc_ValueError, "invalid datasize");
    return NULL;
  }

  rv = PyString_FromStringAndSize(0, size);
  if (!rv)
    goto err;

  rv2 = PyString_FromStringAndSize(0, 16);
  if (!rv2)
    goto err;

  {
    u32	d[4];
    u32	iv[4];
    int	p;
    int	nbytes = size;
    memcpy(iv,ivdata,16);

    for(nbytes = size, p = 0; nbytes > 0; nbytes -= 16, p += 16) {
      memcpy(d,data+p,16);
      D(fprintf(stderr,"e1 %08x %08x %08x %08x\n",d[0],d[1],d[2],d[3]));
      d[0] = d[0]^iv[0];
      d[1] = d[1]^iv[1];
      d[2] = d[2]^iv[2];
      d[3] = d[3]^iv[3];
      D(fprintf(stderr,"e2 %08x %08x %08x %08x\n",d[0],d[1],d[2],d[3]));
      rijndaelEncrypt(ctx->rke, ctx->nr, (u8*)d, (u8*)d);
      D(fprintf(stderr,"e3 %08x %08x %08x %08x\n",d[0],d[1],d[2],d[3]));
      memcpy(&(((PyStringObject*)rv)->ob_sval[p]),d,16);
      iv[0] = d[0];
      iv[1] = d[1];
      iv[2] = d[2];
      iv[3] = d[3];
    }
    memcpy(((PyStringObject*)rv2)->ob_sval,iv,16);
  }
  r = Py_BuildValue("(OO)", rv2, rv);
 err:
  Py_XDECREF(rv2);
  Py_XDECREF(rv);
  return r;
}

PyDoc_STRVAR(_aes_cbcdecrypt_doc,
	     "cbcdecrypt(ctx,iv,data)\n\
\n\
AES CBC decryption");

static PyObject *
_aes_cbcdecrypt(PyObject *self, PyObject *args)
{
  const char	*data;
  int	size;
  const char	*ivdata;
  int	ivsize;
  _Aes *ctx = (_Aes*)self;
  PyObject *rv = 0;
  PyObject *rv2 = 0;
  PyObject *r = 0;

  if (!PyArg_ParseTuple(args, "s#s#", &ivdata, &ivsize, &data, &size))
    return NULL;

  if (ivsize != 16) {
    PyErr_SetString(PyExc_ValueError, "invalid ivsize");
    goto err;
  }

  if ((size % 16) != 0) {
    PyErr_SetString(PyExc_ValueError, "invalid datasize");
    goto err;
  }

  rv = PyString_FromStringAndSize(0, size);
  if (!rv)
    return NULL;

  rv2 = PyString_FromStringAndSize(0, 16);
  if (!rv2)
    return NULL;

  {
    u32	d[4];
    u32	iv[4];
    u32	nextiv[4];
    int	p;
    int	nbytes = size;
    memcpy(iv,ivdata,16);

    for(nbytes = size, p = 0; nbytes > 0; nbytes -= 16, p += 16) {
      memcpy(d,data+p,16);
      D(fprintf(stderr,"d1 %08x %08x %08x %08x\n",d[0],d[1],d[2],d[3]));
      nextiv[0] = d[0];
      nextiv[1] = d[1];
      nextiv[2] = d[2];
      nextiv[3] = d[3];
      rijndaelDecrypt(ctx->rkd, ctx->nr, (u8*)d, (u8*)d);
      D(fprintf(stderr,"d2 %08x %08x %08x %08x\n",d[0],d[1],d[2],d[3]));
      d[0] = d[0]^iv[0];
      d[1] = d[1]^iv[1];
      d[2] = d[2]^iv[2];
      d[3] = d[3]^iv[3];
      D(fprintf(stderr,"d3 %08x %08x %08x %08x\n",d[0],d[1],d[2],d[3]));
      memcpy(&(((PyStringObject*)rv)->ob_sval[p]),d,16);
      iv[0] = nextiv[0];
      iv[1] = nextiv[1];
      iv[2] = nextiv[2];
      iv[3] = nextiv[3];
    }
    memcpy(((PyStringObject*)rv2)->ob_sval,iv,16);
  }
  r = Py_BuildValue("(OO)", rv2, rv);
 err:
  Py_XDECREF(rv2);
  Py_XDECREF(rv);
  return r;
}

static PyMethodDef _Aes_methods[] = {
  {"encrypt",		_aes_encrypt,	METH_VARARGS,
   _aes_encrypt_doc},
  {"decrypt",		_aes_decrypt,	METH_VARARGS,
   _aes_decrypt_doc},
  {"cbcencrypt",		_aes_cbcencrypt,	METH_VARARGS,
   _aes_cbcencrypt_doc},
  {"cbcdecrypt",		_aes_cbcdecrypt,	METH_VARARGS,
   _aes_cbcdecrypt_doc},
  {NULL}  /* Sentinel */
};

static PyTypeObject _AesType = {
  PyObject_HEAD_INIT(NULL)
  0,				/*ob_size*/
  "_aes._Aes",			/*tp_name*/
  sizeof(_Aes),			/*tp_basicsize*/
  0,				/*tp_itemsize*/
  (destructor)_Aes_dealloc,	/*tp_dealloc*/
  0,				/*tp_print*/
  0,				/*tp_getattr*/
  0,				/*tp_setattr*/
  0,				/*tp_compare*/
  0,				/*tp_repr*/
  0,				/*tp_as_number*/
  0,				/*tp_as_sequence*/
  0,				/*tp_as_mapping*/
  0,				/*tp_hash */
  0,				/*tp_call*/
  0,				/*tp_str*/
  0,				/*tp_getattro*/
  0,				/*tp_setattro*/
  0,				/*tp_as_buffer*/
  Py_TPFLAGS_DEFAULT | Py_TPFLAGS_BASETYPE, /*tp_flags*/
  "_Aes objects",		/* tp_doc */
  0,				/* tp_traverse */
  0,				/* tp_clear */
  0,				/* tp_richcompare */
  0,				/* tp_weaklistoffset */
  0,				/* tp_iter */
  0,				/* tp_iternext */
  _Aes_methods,			/* tp_methods */
  0,				/* tp_members */
  0,				/* tp_getset */
  0,				/* tp_base */
  0,				/* tp_dict */
  0,				/* tp_descr_get */
  0,				/* tp_descr_set */
  0,				/* tp_dictoffset */
  (initproc)_Aes_init,		/* tp_init */
  0,				/* tp_alloc */
  _Aes_new,			/* tp_new */
};

static PyMethodDef module_methods[] = {
  {NULL}  /* Sentinel */
};

#ifndef PyMODINIT_FUNC	/* declarations for DLL import/export */
#define PyMODINIT_FUNC void
#endif
PyMODINIT_FUNC
init_aes(void) 
{
  PyObject* m;

  if (PyType_Ready(&_AesType) < 0)
    return;

  m = Py_InitModule3("_aes", module_methods,
		     "Example module that creates an extension type.");

  if (m == NULL)
    return;

  Py_INCREF(&_AesType);
  PyModule_AddObject(m, "Keysetup", (PyObject *)&_AesType);
}
