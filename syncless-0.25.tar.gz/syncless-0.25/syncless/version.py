#! /usr/local/bin/stackless2.6

"""The current version number of Syncless.

This file must be possible to be `exec'ed on its own.
"""

__author__ = 'pts@fazekas.hu (Peter Szabo)'

VERSION = '0.25'
