#! /usr/bin/env python

import sys
import getopt
import os
import binascii

import aes

def usage(utyp, *msg):
    sys.stderr.write('Usage: %s\n' % os.path.split(sys.argv[0])[1])
    if msg:
        sys.stderr.write('Error: %s\n' % `msg`)
    sys.exit(1)

class Global:
    def __init__(gp):
        return
    def doit(gp,args):
        fout = sys.stdout
        fout.write('START\n')
        fout.flush()
        for a in args:
            o = aes.Keysetup(a)
            fout.write('%s: %s\n' % (a,o))
            fout.flush()
            iv = '\x00' * 16
            for l in xrange(16,128,16):
                pt0 = '.'*l
                iv2,ct = o.cbcencrypt(iv,pt0)
                fout.write('cbce: %s: %s\n' % (a,binascii.b2a_hex(ct),))
                fout.flush()
                ct_e = o.encrypt(pt0[:16])
                fout.write('ecbe: %s: %s\n' % (a,binascii.b2a_hex(ct_e),))
                fout.flush()
                iv3,pt = o.cbcdecrypt(iv,ct)
                fout.write('cbcd: %s: %s\n' % (a,pt,))
                fout.flush()
                pt_e = o.decrypt(ct_e)
                fout.write('ecbd: %s: %s\n' % (a,pt_e,))
                fout.flush()
            fout.flush()
        return

def main(argv):
    gp = Global()
    try:
        opts, args = getopt.getopt(sys.argv[1:],
                                   'hf:c:',['help',
                                            'file=',
                                            'count=',
                                            ])
    except getopt.error, msg:
        usage(1, msg)

    for opt, arg in opts:
        if opt in ('-h', '--help'):
            usage(0)
        elif opt in ('-f', '--file'):
            gp.tarfilename = arg
        elif opt in ('-c', '--count'):
            gp.fetchcount = int(arg)

    gp.doit(args)
        
if __name__ == '__main__':
    main(sys.argv)
