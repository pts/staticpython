.. _install:

.. include:: ../INSTALL.TXT
