#
#   Pyrex -- Main Program, generic
#

from Pyrex.Compiler.Main import main
main(command_line = 1)
