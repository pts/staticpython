:mod:`concurrence.database.mysql.client` -- The concurrence mysql driver module
===============================================================================

.. module:: concurrence.database.mysql.client
   :platform: Unix
   :synopsis: Provides the low-level Concurrence MySQL client.
.. moduleauthor:: Henk Punt <henk@hyves.nl>
 
.. autoclass:: Connection
   :members:
   
.. autoclass:: ResultSet
   :members:
      
   
