#! /usr/local/bin/stackless2.6

assert 0, 'see ../syncless/best_greenlet.py instead'
