#! /usr/bin/env python
from distutils.core import setup,Extension
from distutils.sysconfig import get_python_inc

AESSOURCES = ["aes/rijndael-alg-fst.c",
              "aes/aesmodule.c"]

setup(name="alo-aes",
      version="0.3",
      description="Python AES module.",
      author="Antti Louko",
      author_email="alo@iki.fi",
      url="http://www.louko.com/alo-aes/",
      license="GNU GENERAL PUBLIC LICENSE",
      
      packages = ["aes"],
      ext_modules = [Extension("aes._aes",
                               sources=AESSOURCES,
                               include_dirs=[get_python_inc(plat_specific=1)]),
                     ]
      )
